package com.ahmetocak.shoppingapp.model.auth

data class Auth(
    val email: String,
    val password: String
)
