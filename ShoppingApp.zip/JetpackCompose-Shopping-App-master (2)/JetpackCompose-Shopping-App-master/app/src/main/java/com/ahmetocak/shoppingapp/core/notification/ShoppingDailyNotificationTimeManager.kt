package com.ahmetocak.shoppingapp.core.notification

object ShoppingDailyNotificationTimeManager {
    const val REMINDER_HOUR = 20
    const val REMINDER_MINUTES = 0
}