package com.ahmetocak.shoppingapp.model.user_detail

data class UserDetail(
    val address: String? = null,
    val birthdate: Long? = null
)
